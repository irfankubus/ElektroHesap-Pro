@echo off
setlocal
cd /d "%~dp0"

echo.
echo ============================================================
echo             ElektroHesap Pro - BASLATILIYOR
echo ============================================================
echo.

where python >nul 2>&1
if errorlevel 1 (
  echo [HATA] Python bulunamadi.
  echo Python 3.9+ kurun ve PATH'e ekleyin.
  pause
  exit /b 1
)

echo [1/4] Backend ortami kontrol ediliyor...
cd /d "%~dp0backend"

if not exist "venv\Scripts\python.exe" (
  echo Sanal ortam olusturuluyor...
  python -m venv venv
  if errorlevel 1 (
    echo [HATA] Python sanal ortami olusturulamadi.
    pause
    exit /b 1
  )
)

if not exist ".env" (
  (
    echo MONGO_URL=mongodb://localhost:27017
    echo DB_NAME=elektrohesap
    echo CORS_ORIGINS=*
  ) > .env
)

echo [2/4] Backend paketleri yukleniyor...
venv\Scripts\python.exe -m pip install -q -r requirements.txt
if errorlevel 1 (
  echo [HATA] Backend paketleri yuklenemedi.
  pause
  exit /b 1
)

echo [3/4] Backend baslatiliyor: http://localhost:8001
start "ElektroHesap Backend" /D "%~dp0backend" cmd /k "venv\Scripts\python.exe -m uvicorn server:app --host 0.0.0.0 --port 8001 --reload"

echo [4/4] Frontend baslatiliyor: http://localhost:3000
start "ElektroHesap Frontend" /D "%~dp0frontend\public" cmd /k "python -m http.server 3000 --bind 0.0.0.0"

timeout /t 3 /nobreak >nul
start "" "http://localhost:3000/"

echo.
echo ============================================================
echo Hazir!
echo Ana Sayfa : http://localhost:3000/
echo API Docs  : http://localhost:8001/docs
echo ============================================================
echo.
echo Acilan iki CMD penceresini kapatarak uygulamayi durdurabilirsiniz.
pause
